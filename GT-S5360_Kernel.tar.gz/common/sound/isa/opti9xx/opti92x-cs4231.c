#define CS4231
#include "opti92x-ad1848.c"
