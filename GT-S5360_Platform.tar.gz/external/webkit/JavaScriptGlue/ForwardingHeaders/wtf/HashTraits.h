#include <JavaScriptCore/HashTraits.h>
