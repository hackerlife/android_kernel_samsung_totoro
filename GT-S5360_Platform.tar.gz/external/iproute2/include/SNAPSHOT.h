static const char SNAPSHOT[] = "091226";
